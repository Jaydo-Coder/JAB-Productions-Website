$('.nav-item').on('click', function() {
	$('.navbar-collapse').collapse('hide');
});

$(document).click(function(event) {
	$('.navbar-collapse').collapse('hide');
});
